require "install/version"

module Install
  # Your code goes here...
end
